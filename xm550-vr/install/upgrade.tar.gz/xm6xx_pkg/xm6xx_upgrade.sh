#!/bin/sh

HOME_PATH=/var/sd
#emmc
EMMC_USR_PATH="$HOME_PATH"/usr


#upgrade
VRAPP_NAME=vrapp


cp $VRAPP_NAME $EMMC_USR_PATH/

